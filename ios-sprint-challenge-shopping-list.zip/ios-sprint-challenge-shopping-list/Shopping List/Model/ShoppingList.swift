//
//  ShoppingList.swift
//  Shopping List
//
//  Created by Bohdan Tkachenko on 5/2/20.
//  Copyright © 2020 Lambda School. All rights reserved.
//


import UIKit

struct ShoppingList: Codable, Equatable {
    
    var name: String
    var hasBeenAdded: Bool
    var image: UIImage {
        return UIImage(named: name)!
    }
    
    init(itemName: String, hasBeenAdded: Bool = false) {
        self.name = itemName
        self.hasBeenAdded = hasBeenAdded
        
        
    }
    
}


