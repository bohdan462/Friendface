//
//  OrderViewController.swift
//  Shopping List
//
//  Created by Bohdan Tkachenko on 5/2/20.
//  Copyright © 2020 Lambda School. All rights reserved.
//

import UIKit

class OrderViewController: UIViewController {
    


    @IBOutlet weak var addressTextField: UITextField!
    @IBOutlet weak var currentNumberOfItemsLabel: UILabel!
    @IBOutlet weak var nameTextField: UITextField!
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        guard let shoppingListController = shoppingListController else { return }
        orderItems = shoppingListController.fruitItemAdded.count
        currentNumberOfItemsLabel.text = "You have \(orderItems) items in your shopping cart."
    }
    

    @IBAction func sendOrderButtonTapped(_ sender: Any) {
        if let name = nameTextField.text, !name.isEmpty,
            let address = addressTextField.text, !address.isEmpty {
            let alert = UIAlertController(title: "Delivery for \(name)", message: "The \(orderItems) items in your shopping cart will be shipped to \(address) in 30 minutes", preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
            self.present(alert, animated: true, completion: nil)
        }
    }
    
    var shoppingListController: ShoppingListController?
    var orderItems = 0

}
