//
//  ShoppingListController.swift
//  Shopping List
//
//  Created by Bohdan Tkachenko on 5/2/20.
//  Copyright © 2020 Lambda School. All rights reserved.
//

import Foundation


class ShoppingListController {
    
    init() {
       loadFromPresistentStore()
        if shoppingList.count == 0 {
            for item in itemName {
                shoppingList.append(ShoppingList(itemName: item))
                print(shoppingList)
            }
            saveToPresistentStore()
        }
    }
    
    
    // Presistence

    //Create
    private var shoppingListURL: URL? {
        let fm = FileManager.default
        guard let documentDirectory = fm.urls(for: .documentDirectory, in: .userDomainMask).first else { return nil }
        let fileName = "ShoppingItem.plist"
        return documentDirectory.appendingPathComponent(fileName)
    }

    //Save
    func saveToPresistentStore() {
        let plistEncoder = PropertyListEncoder()
              
              do {
                  let itemsData = try plistEncoder.encode(shoppingList)
                  
                  guard let fileURL = shoppingListURL else { return }
                  
                  try itemsData.write(to: fileURL)
              } catch {
                  NSLog("Error encoding memories to property list: \(error)")
              }    }

    //Load
    func loadFromPresistentStore() {
        do {
                   guard let fileURL = shoppingListURL else { return }
                   
                   let itemsData = try Data(contentsOf: fileURL)
                   
                   let plistDecoder = PropertyListDecoder()
                   
                   self.shoppingList = try plistDecoder.decode([ShoppingList].self, from: itemsData)
               } catch {
                   NSLog("Error decoding memories from property list: \(error)")
               }
    }
    
    
    

    
   
    
    
    
    
    let itemName = ["Apple", "Grapes", "Milk", "Muffin", "Popcorn", "Soda", "Strawberries"]
    
    var shoppingList: [ShoppingList] = []
    
    var fruitItemAdded : [ShoppingList] {
        saveToPresistentStore()
        return shoppingList.filter{$0.hasBeenAdded == true}
        
    }
}
